// 复用一个已有库的promise，以减少体积。当有问题找不到了后换一个可用的
module.exports = require('es6-promise')
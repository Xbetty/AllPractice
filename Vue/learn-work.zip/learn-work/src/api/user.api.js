import envConfig from '../config/index.js'
import axios from 'axios'
let apiHost = envConfig.apiHost
export default {
	getInfos () {
		return axios.get(`${apiHost}/getInfos`)
	},
	addInfos (form) {
		return axios.post(`${apiHost}/addInfos`, form)
	},
	removeInfos (id) {
		return axios.post(`${apiHost}/removeInfos`, {
			_id: id
		})
	},
	updateInfos (form) {
		return axios.post(`${apiHost}/updateInfos`, form)
	}
}
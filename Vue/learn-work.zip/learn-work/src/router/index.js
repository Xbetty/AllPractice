import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/page/home.vue'
import InfoManage from '@/page/infos/infoManage.vue'
Vue.use(Router)

export default new Router({
	mode: 'history',
	routes: [
		{
			path: '/',
	      	redirect: '/home'
		},
	    {
	        path: '/home',
	        name: 'Home',
	        component: Home,
	        children: [{
	        	path: '/infoManage',
		        name: 'infoManage',
		        component: InfoManage
	        }]
	    }
	]
})

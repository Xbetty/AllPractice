const protocol = window.location.protocol
const apiHost = `${protocol}//192.168.28.47:3000`
export default {
	apiHost: apiHost
}